import React, { useEffect, useState } from 'react';

function App() {
  const [moods, setMoods] = useState([]);
  const [note, setNote] = useState('');
  const [color, setColor] = useState('#a3d8f4');

  // Fetch moods from backend
  useEffect(() => {
    fetch('http://localhost:5000/api/moods')
      .then(res => res.json())
      .then(data => setMoods(data))
      .catch(err => console.error('Error loading moods:', err));
  }, []);

 useEffect(() => {
  fetch('http://localhost:5000/api/moods')
    .then(res => res.json())
    .then(data => setMoods(data))
    .catch(err => console.error('Error loading moods:', err));
}, []);

const handleSubmit = (e) => {
  e.preventDefault();
  const newMood = { color, note };

  fetch('http://localhost:5000/api/moods', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(newMood)
  })
    .then(res => res.json())
    .then(savedMood => {
      setMoods(prev => [savedMood, ...prev]);
      setNote('');
    })
    .catch(err => console.error('Error saving mood:', err));
};

  // Handle delete
  const handleDelete = (id) => {
    fetch(`http://localhost:5000/api/moods/${id}`, {
      method: 'DELETE'
    })
      .then(() => setMoods(prev => prev.filter(m => m._id !== id)))
      .catch(err => console.error('Error deleting mood:', err));
  };

  return (
    <div style={{ padding: 20, background: '#f7fbff', minHeight: '100vh' }}>
      <h1>MindHue</h1>
      <form onSubmit={handleSubmit}>
        <input type="color" value={color} onChange={e => setColor(e.target.value)} />
        <br />
        <textarea
          value={note}
          onChange={e => setNote(e.target.value)}
          placeholder="Short note..."
          required
        />
        <br />
        <button type="submit">Save</button>
      </form>

      <hr />
      <ul>
        {moods.map((m, idx) => (
          <li key={m._id || idx} style={{ background: m.color, margin: '10px 0', padding: 8 }}>
            {m.note} <small>({new Date(m.date).toLocaleString()})</small>
            <button
              onClick={() => handleDelete(m._id)}
              style={{ marginLeft: 10 }}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;